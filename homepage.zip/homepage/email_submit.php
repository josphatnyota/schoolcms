<?php
require ("db_con.php");

if(isset($_POST['submit_email'])){
	
	$email = filter_var($_POST['email'],FILTER_SANITIZE_STRING, FILTER_FLAG_STRIP_HIGH);
	
		$sql = mysqli_query($link,"INSERT INTO subscribers(email) VALUES ('".$email."')") or die (mysqli_error());
		
		header('location:index.php?success');
		
		exit();	
					
	}



?>