	
		<div class="fullwidth-block testimonial-section">
				
						<div class="quote-slider">
							<ul class="slides">
								<li>
									<blockquote>
										<p>"Testimonial 1Testimonial 1"</p>
										<cite>Mr. Parent</cite>
										<span>PTA</span>
									</blockquote>
								</li>
								<li>
									<blockquote>
										<p>"Testimonial 2"</p>
										<cite>Mrs. Parent</cite>
										<span>BOG</span>
									</blockquote>
								</li>
																<li>
									<blockquote>
										<p>"Testimonial 3"</p>
										<cite>Teacher</cite>
										<span>Chemistry</span>
									</blockquote>
								</li>
							</ul>
						</div>
					</div>
				 