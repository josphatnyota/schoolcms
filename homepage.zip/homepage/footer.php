
			<footer class="site-footer">
				
					<img src="dummy/logo-footer.png" alt="Sunshine logo">
					
					<address>
						<p>Location <br><a href="tel:9488487853">Telephone</a> <br> <a href="#">email</a></p> 
					</address> 
						<form action="email_submit.php" method="POST"  ROLE="form"class="newsletter-form">
						<input type="email" name="email"  onchange="email_validate(this.value);" required placeholder="Enter your email to get newsletter...">
						<input type="submit" name="submit_email" class="button cut-corner" value="Subscribe">
					</form> <!-- .newsletter-form -->
					
            
					
					
					<div class="social-links">
						<a href="#"><i class="fa fa-facebook-square"></i></a>
						<a href="#"><i class="fa fa-twitter"></i></a>
						<a href="#"><i class="fa fa-google-plus"></i></a>
						<a href="#"><i class="fa fa-pinterest"></i></a>
					</div> 
					
					<p class="copy">Sunshine Boy's High School @ Copyright 2018. All right reserved. Designed by <a href="http://zalego.ac.ke">Zalego Institute</a></p>
			
			</footer> 

		</div>

		<script src="js/jquery-1.11.1.min.js"></script>		
		<script src="js/plugins.js"></script>
		<script src="js/app.js"></script>
		<script src="js/jquery.gmap.min.js"></script>
	</body>

</html>