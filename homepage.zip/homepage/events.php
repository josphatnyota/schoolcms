
				<div class="fullwidth-block upcoming-event-section" data-bg-color="#4b4980">
					
						<header class="section-header">
							<h2 class="section-title">Upcoming events</h2>

							<div class="event-nav">
								<a class="prev" id="event-prev" href="#"><i class="fa fa-caret-left"></i></a>
	    						<a class="next" id="event-next" href="#"><i class="fa fa-caret-right"></i></a>
							</div> 

						</header> 
						<div class="event-carousel">
							
							<div class="event">
								
								<h2 class="entry-title"><a href="#">Event Date</a></h2>
								<h2>Event Title</h2>
								<p>Details about the eventDetails about the eventDetails about the eventDetails about the eventDetails about the eventDetails about the eventDetails about the eventDetails about the eventDetails about the event</p>
							<p>Details about the event</p>
							</div> 
							
							
							<div class="event">
								
								<h2 class="entry-title"><a href="#">Event Date</a></h2>
								<p>About event 2Details about the eventDetails about the eventDetails about the eventDetails about the event</p>
							</div> 
							
							
							<div class="event">
								
								<h2 class="entry-title"><a href="#">Event date </a></h2>
								<p>Event 3 detailsDetails about the eventDetails about the eventDetails about the eventDetails about the event</p>
							</div> 
							
							
							<div class="event">
								
								<h2 class="entry-title"><a href="#">Event Date</a></h2>
								<p>Event 4 detailsDetails about the eventDetails about the eventDetails about the eventDetails about the event </p>
								
							</div> 
							
							
							<div class="event">
								
								<h2 class="entry-title"><a href="#">event 5</a></h2>
								<p>Event 5 details</p>
							</div> 
							
						</div> 
					</div> 
			

<!--upcoming-event-section END-->