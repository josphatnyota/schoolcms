
		<?php include "header.php"?>
		<div class="container">
         <div class="nav">
		 <header id="navigation" class="navbar-inverse navbar-fixed-top animated-header">
           
               

			
					<a href="index.php" id="branding">
						<img src="dummy/logo.png" alt="School logo">
						<small class="site-description">Sunshine boys high school</small>
					</a> <!-- #branding -->
					
					<nav class="main-navigation">
						<button type="button" class="toggle-menu"><i class="fa fa-bars"></i></button>
						<ul class="menu">
							<li class="menu-item"><a href="index.php">Home</a></li>
							<li class="menu-item"><a href="about.php">About</a></li>
							<li class="menu-item"><a href="#">Admission & Fees</a></li>
							<li class="menu-item"><a href="gallery.php">Gallery</a></li>
							<li class="menu-item"><a href="contact.php">Contact us</a></li>
							<li class="menu-item"><a href="tender.php">Tenders</a></li>
							
						</ul> <!-- .menu -->
					</nav> <!-- .main-navigation -->
					<div class="mobile-menu"></div>
				</div>
				<!-- /main nav -->
				
            
        </header>
		
		</div>
		
		
		
        <!--
        End Fixed Navigation
        ==================================== -->
		